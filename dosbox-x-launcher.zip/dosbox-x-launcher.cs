using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;

internal static class Program
{
    private static void Main(string[] args)
    {
        var key = Registry.CurrentUser.OpenSubKey(@"Software\Classes\Applications\dosbox-x-launcher.exe\shell\open\command");
        if (key == null || !(key.GetValue(null) is string)) {
            key = Registry.CurrentUser.CreateSubKey(@"Software\Classes\Applications\dosbox-x-launcher.exe\shell\open\command");
            key.SetValue(null, "\"" + System.Reflection.Assembly.GetEntryAssembly().Location + "\" \"%1\" %2 %3 %4 %5 %6 %7 %8 %9");
        }
        key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\DOSBox-X");
        if (key == null || !(key.GetValue("Location") is string)) {
            if (File.Exists(@"C:\DOSBox-X\DOSBox-X.exe")) {
                key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\DOSBox-X");
                key.SetValue("Location", @"C:\DOSBox-X\DOSBox-X.exe");
                key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\DOSBox-X");
                if (key == null || !(key.GetValue("Location") is string))
                    return;
            } else
                return;
        }
        string dosbox = key.GetValue("Location").ToString();
        if (args.Length != 0)
        {
            var fileName  = args[0];
            var arguments = string.Join(" ", args.Skip(1));
            if (NativeMethods.GetBinaryType(fileName, out var fileType)) {
                key = Registry.CurrentUser.OpenSubKey(@"Software\Classes\.exe", true);
                key.SetValue(null, "exefile");
                if (fileType == 1) { // SCS_DOS_BINARY
                    arguments = $@"-fastlaunch -defaultdir ""{Path.GetDirectoryName(dosbox)}"" ""{fileName}""";
                    fileName = dosbox;
                }
                Process.Start(fileName, arguments);
                key.SetValue(null, "Applications\\dosbox-x-launcher.exe");
                key.Close();
            }
        }
    }
}

internal static class NativeMethods
{
    [DllImport("Kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool GetBinaryType(string lpApplicationName, out uint lpBinaryType);
}
